import math
from functools import lru_cache
from typing import Dict, List, Tuple

import requests


# ============================================================
# Bilingual intent router for CMMS AI assistant
# ============================================================
# This file keeps the same public functions used by rag_api.py:
# - detect_route(question)
# - detect_sql_intent(question)
#
# Design:
# - Uses semantic intent examples in English + French.
# - Uses nomic-embed-text through Ollama.
# - Falls back to keyword rules if Ollama embedding is unavailable.
# - Does NOT generate SQL.
# - Only returns allowlisted intents.
# ============================================================


OLLAMA_EMBED_URL = "http://localhost:11434/api/embeddings"
EMBED_MODEL = "nomic-embed-text"


# ============================================================
# Intent registry
# ============================================================

INTENTS: Dict[str, Dict] = {
    "top_equipment_by_claims": {
        "route": "SQL",
        "examples": [
            "What are the top equipment with the most claims?",
            "Show the top 3 equipment by claim count.",
            "Which equipment has the most claims?",
            "Which assets have the most complaints?",
            "Top equipment by number of claims.",
            "Quels équipements ont le plus de réclamations ?",
            "Montre les 3 équipements avec le plus de réclamations.",
            "Quels actifs ont le plus de plaintes ?",
            "Top des équipements par nombre de réclamations.",
        ],
    },
    "top_equipment_by_claims_explanation": {
        "route": "HYBRID",
        "maps_to_sql_intent": "top_equipment_by_claims",
        "examples": [
            "Why do the top 3 equipment have the most claims?",
            "Explain the top 3 equipment with the most claims.",
            "What are the causes behind the top equipment by claim count?",
            "Why are the most claimed equipment problematic?",
            "Explain why these equipment have many claims.",
            "Pourquoi les 3 équipements principaux ont-ils le plus de réclamations ?",
            "Explique les équipements avec le plus de réclamations.",
            "Quelles sont les causes derrière les équipements les plus réclamés ?",
            "Pourquoi ces équipements ont-ils beaucoup de réclamations ?",
        ],
    },
    "count_open_work_orders": {
        "route": "SQL",
        "examples": [
            "How many open work orders are there?",
            "Count open work orders.",
            "Number of active work orders.",
            "How many work orders are not closed?",
            "Combien d’ordres de travail sont ouverts ?",
            "Nombre d’ordres de travail actifs.",
            "Combien d’OT ne sont pas fermés ?",
            "Compter les ordres de travail ouverts.",
        ],
    },
    "count_open_claims": {
        "route": "SQL",
        "examples": [
            "How many open claims are there?",
            "Count open claims.",
            "Number of unresolved claims.",
            "How many claims are not closed?",
            "Combien de réclamations sont ouvertes ?",
            "Nombre de réclamations non résolues.",
            "Combien de réclamations ne sont pas fermées ?",
            "Compter les réclamations ouvertes.",
        ],
    },
    "spare_parts_below_min_stock": {
        "route": "SQL",
        "examples": [
            "Which spare parts are below minimum stock?",
            "Show low stock spare parts.",
            "Which parts are under the minimum stock level?",
            "List spare parts with insufficient stock.",
            "Quelles pièces sont sous le stock minimum ?",
            "Afficher les pièces en stock faible.",
            "Quelles pièces de rechange sont en dessous du niveau minimum ?",
            "Lister les pièces avec stock insuffisant.",
        ],
    },
    "overdue_work_orders": {
        "route": "SQL",
        "examples": [
            "Which work orders are overdue?",
            "Show overdue work orders.",
            "List delayed work orders.",
            "Which work orders passed their due date?",
            "Quels ordres de travail sont en retard ?",
            "Afficher les OT en retard.",
            "Lister les ordres de travail dépassés.",
            "Quels ordres de travail ont dépassé la date limite ?",
        ],
    },
    "work_orders_by_status": {
        "route": "SQL",
        "examples": [
            "Show work orders by status.",
            "Count work orders by status.",
            "Break down work orders by status.",
            "Work order status summary.",
            "Afficher les ordres de travail par statut.",
            "Compter les OT par statut.",
            "Résumé des ordres de travail par statut.",
            "Répartition des ordres de travail par statut.",
        ],
    },
    "claims_by_priority": {
        "route": "SQL",
        "examples": [
            "Show claims by priority.",
            "Count claims by priority.",
            "Break down claims by priority.",
            "Claim priority summary.",
            "Afficher les réclamations par priorité.",
            "Compter les réclamations par priorité.",
            "Résumé des réclamations par priorité.",
            "Répartition des réclamations par priorité.",
        ],
    },
    "rag_semantic": {
        "route": "RAG",
        "examples": [
            "Why was this work order cancelled?",
            "What happened with this equipment?",
            "Explain the issue reported in this claim.",
            "What was done to fix the task?",
            "Why is this task blocked?",
            "Summarize the maintenance history for this asset.",
            "Pourquoi cet ordre de travail a-t-il été annulé ?",
            "Que s’est-il passé avec cet équipement ?",
            "Explique le problème signalé dans cette réclamation.",
            "Pourquoi cette tâche est-elle bloquée ?",
            "Résume l’historique de maintenance de cet actif.",
        ],
    },
}


# Keep only currently supported SQL intents in rag_api.py/sql_tools.py.
SUPPORTED_SQL_INTENTS = {
    "top_equipment_by_claims",
    "count_open_work_orders",
    "count_open_claims",
    "spare_parts_below_min_stock",
    "overdue_work_orders",
    "work_orders_by_status",
    "claims_by_priority",
}


# Current rag_api.py supports only this HYBRID intent safely.
SUPPORTED_HYBRID_INTENTS = {
    "top_equipment_by_claims_explanation",
}


# Confidence thresholds.
# If confidence is low, we prefer RAG because it is safer than running a wrong SQL intent.
ROUTE_CONFIDENCE_THRESHOLD = 0.58
SQL_CONFIDENCE_THRESHOLD = 0.58


# ============================================================
# Embedding + similarity
# ============================================================

def _ollama_embed(text: str) -> List[float]:
    response = requests.post(
        OLLAMA_EMBED_URL,
        json={
            "model": EMBED_MODEL,
            "prompt": text,
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()["embedding"]


def _cosine_similarity(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0

    dot = 0.0
    norm_a = 0.0
    norm_b = 0.0

    for x, y in zip(a, b):
        dot += x * y
        norm_a += x * x
        norm_b += y * y

    if norm_a <= 0 or norm_b <= 0:
        return 0.0

    return dot / (math.sqrt(norm_a) * math.sqrt(norm_b))


@lru_cache(maxsize=512)
def _embed_cached(text: str) -> Tuple[float, ...]:
    return tuple(_ollama_embed(text))


def _get_text_embedding(text: str) -> List[float]:
    return list(_embed_cached(text.strip()))


def _build_example_index() -> List[Dict]:
    index = []

    for intent, config in INTENTS.items():
        for example in config["examples"]:
            try:
                embedding = _get_text_embedding(example)
                index.append({
                    "intent": intent,
                    "route": config["route"],
                    "example": example,
                    "embedding": embedding,
                })
            except Exception:
                # If embeddings fail during startup/import, we keep fallback routing available.
                pass

    return index


@lru_cache(maxsize=1)
def _example_index_cached() -> Tuple[Tuple[str, str, str, Tuple[float, ...]], ...]:
    rows = []

    for intent, config in INTENTS.items():
        for example in config["examples"]:
            try:
                embedding = tuple(_get_text_embedding(example))
                rows.append((intent, config["route"], example, embedding))
            except Exception:
                pass

    return tuple(rows)


def _classify_with_embeddings(question: str) -> Dict:
    question_embedding = _get_text_embedding(question)

    best_intent = "rag_semantic"
    best_route = "RAG"
    best_score = -1.0
    best_example = ""

    for intent, route, example, example_embedding_tuple in _example_index_cached():
        score = _cosine_similarity(question_embedding, list(example_embedding_tuple))

        if score > best_score:
            best_score = score
            best_intent = intent
            best_route = route
            best_example = example

    return {
        "intent": best_intent,
        "route": best_route,
        "confidence": best_score,
        "matched_example": best_example,
    }


# ============================================================
# Fallback keyword logic
# ============================================================

def _fallback_detect_route(question: str) -> str:
    q = question.lower()

    hybrid_phrases = [
        "why do the top",
        "why are the top",
        "why does the top",
        "why is the top",
        "explain the top",
        "reason for the top",
        "reasons for the top",
        "causes behind",
        "why do equipment",
        "why are equipment",
        "pourquoi les 3 équipements",
        "pourquoi les 3 equipements",
        "explique les équipements",
        "explique les equipements",
        "causes derrière",
        "causes derriere",
    ]

    if any(phrase in q for phrase in hybrid_phrases):
        return "HYBRID"

    sql_words = [
        "how many",
        "count",
        "number of",
        "top",
        "most",
        "least",
        "average",
        "total",
        "by status",
        "by priority",
        "below minimum",
        "low stock",
        "overdue",
        "combien",
        "nombre de",
        "le plus",
        "les plus",
        "par statut",
        "par priorité",
        "par priorite",
        "stock minimum",
        "stock faible",
        "en retard",
    ]

    if any(word in q for word in sql_words):
        return "SQL"

    return "RAG"


def _fallback_detect_sql_intent(question: str) -> str:
    q = question.lower()

    equipment_words = ["equipment", "asset", "équipement", "equipement", "équipements", "equipements", "actif", "actifs"]
    claim_words = ["claim", "claims", "réclamation", "reclamation", "réclamations", "reclamations", "plainte", "plaintes"]
    work_order_words = ["work order", "work orders", "wo", "ordre de travail", "ordres de travail", "ot"]
    part_words = ["spare", "part", "parts", "stock", "pièce", "piece", "pièces", "pieces"]

    if ("top" in q or "most" in q or "plus" in q) and any(w in q for w in equipment_words) and any(w in q for w in claim_words):
        return "top_equipment_by_claims"

    if ("how many" in q or "count" in q or "number of" in q or "combien" in q or "nombre de" in q) and any(w in q for w in work_order_words):
        return "count_open_work_orders"

    if ("how many" in q or "count" in q or "number of" in q or "combien" in q or "nombre de" in q) and any(w in q for w in claim_words):
        return "count_open_claims"

    if any(w in q for w in part_words) and (
        "below minimum" in q
        or "low stock" in q
        or "minimum stock" in q
        or "stock minimum" in q
        or "stock faible" in q
        or "sous le stock" in q
    ):
        return "spare_parts_below_min_stock"

    if ("overdue" in q or "en retard" in q) and any(w in q for w in work_order_words):
        return "overdue_work_orders"

    if any(w in q for w in work_order_words) and ("status" in q or "statut" in q):
        return "work_orders_by_status"

    if any(w in q for w in claim_words) and ("priority" in q or "priorité" in q or "priorite" in q):
        return "claims_by_priority"

    return "unknown_sql"


# ============================================================
# Public API used by rag_api.py
# ============================================================

@lru_cache(maxsize=512)
def classify_question(question: str) -> Dict:
    question = question.strip()

    if not question:
        return {
            "intent": "rag_semantic",
            "route": "RAG",
            "confidence": 0.0,
            "matched_example": "",
            "method": "empty",
        }

    try:
        result = _classify_with_embeddings(question)
        result["method"] = "embedding"

        # Safety: unsupported hybrid intents fall back to RAG for now.
        # Current rag_api.py only implements top_equipment_by_claims_explanation as HYBRID.
        if result["route"] == "HYBRID" and result["intent"] not in SUPPORTED_HYBRID_INTENTS:
            result["route"] = "RAG"
            result["intent"] = "rag_semantic"

        # Low confidence fallback.
        if result["confidence"] < ROUTE_CONFIDENCE_THRESHOLD:
            fallback_route = _fallback_detect_route(question)
            fallback_intent = _fallback_detect_sql_intent(question) if fallback_route == "SQL" else "rag_semantic"

            # If fallback thinks HYBRID, keep only supported hybrid.
            if fallback_route == "HYBRID":
                fallback_intent = "top_equipment_by_claims_explanation"

            return {
                "intent": fallback_intent,
                "route": fallback_route,
                "confidence": result["confidence"],
                "matched_example": result["matched_example"],
                "method": "fallback_low_confidence",
            }

        return result

    except Exception:
        fallback_route = _fallback_detect_route(question)

        if fallback_route == "SQL":
            fallback_intent = _fallback_detect_sql_intent(question)
        elif fallback_route == "HYBRID":
            fallback_intent = "top_equipment_by_claims_explanation"
        else:
            fallback_intent = "rag_semantic"

        return {
            "intent": fallback_intent,
            "route": fallback_route,
            "confidence": 0.0,
            "matched_example": "",
            "method": "fallback_error",
        }


def detect_route(question: str):
    result = classify_question(question)

    route = result["route"]

    # If the semantic router suggests SQL but the SQL intent is unknown,
    # avoid wrong SQL execution and use RAG.
    if route == "SQL":
        intent = detect_sql_intent(question)
        if intent == "unknown_sql":
            return "RAG"

    return route


def detect_sql_intent(question: str):
    result = classify_question(question)
    intent = result["intent"]

    if intent == "top_equipment_by_claims_explanation":
        return "top_equipment_by_claims"

    if intent in SUPPORTED_SQL_INTENTS:
        return intent

    # If the embedding result was RAG/HYBRID, fallback may still detect an exact SQL intent.
    fallback_intent = _fallback_detect_sql_intent(question)

    if fallback_intent in SUPPORTED_SQL_INTENTS:
        return fallback_intent

    return "unknown_sql"