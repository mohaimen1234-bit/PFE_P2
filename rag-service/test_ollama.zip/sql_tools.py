from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List

import psycopg2
from psycopg2.extras import RealDictCursor

from db_config import DB_CONFIG


# ============================================================
# SQL tools for secured CMMS assistant
# ============================================================
# Rules:
# - No user-generated SQL.
# - Only predefined, allowlisted SQL templates.
# - No admin/security tables.
# - No password/token/security fields.
# - Read maintenance/operational data only.
# ============================================================


# =========================
# JSON-safe helpers
# =========================

def json_safe_value(value):
    if isinstance(value, Decimal):
        return float(value)

    if isinstance(value, (datetime, date)):
        return value.isoformat()

    return value


def json_safe_row(row: Dict[str, Any]) -> Dict[str, Any]:
    return {key: json_safe_value(value) for key, value in row.items()}


def run_query(sql: str, params=None) -> List[Dict[str, Any]]:
    if params is None:
        params = []

    conn = psycopg2.connect(**DB_CONFIG)

    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
            return [json_safe_row(dict(row)) for row in rows]
    finally:
        conn.close()


# =========================
# Core SQL route queries
# =========================

def top_equipment_by_claims(limit: int = 3):
    limit = max(1, min(int(limit), 20))

    sql = """
    SELECT
        e.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        e.location,
        COUNT(c.claim_id) AS claim_count
    FROM claims c
    JOIN equipment e ON e.equipment_id = c.equipment_id
    GROUP BY
        e.equipment_id,
        e.asset_code,
        e.name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        e.location
    ORDER BY claim_count DESC, e.equipment_id ASC
    LIMIT %s;
    """
    return run_query(sql, [limit])


def count_open_work_orders():
    sql = """
    SELECT COUNT(*) AS open_work_orders
    FROM work_orders
    WHERE status NOT IN ('COMPLETED', 'VALIDATED', 'CLOSED', 'CANCELLED')
      AND COALESCE(is_archived, false) = false;
    """
    return run_query(sql)


def count_open_claims():
    sql = """
    SELECT COUNT(*) AS open_claims
    FROM claims
    WHERE status NOT IN ('RESOLVED', 'CLOSED', 'REJECTED');
    """
    return run_query(sql)


def spare_parts_below_min_stock():
    sql = """
    SELECT
        part_id,
        sku,
        name,
        category,
        quantity_in_stock,
        min_stock_level,
        unit_cost,
        location,
        supplier
    FROM spare_parts
    WHERE quantity_in_stock < min_stock_level
      AND COALESCE(is_archived, false) = false
    ORDER BY quantity_in_stock ASC, name ASC
    LIMIT 20;
    """
    return run_query(sql)


def overdue_work_orders():
    sql = """
    SELECT
        wo.wo_id,
        ('work_orders_' || wo.wo_id) AS source_id,
        wo.claim_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        e.location,
        wo.title,
        wo.description,
        wo.status,
        wo.priority,
        wo.wo_type,
        wo.created_at,
        wo.updated_at,
        wo.due_date,
        wo.planned_start,
        wo.planned_end,
        wo.completed_at,
        wo.cancellation_notes,
        wo.completion_notes,
        wo.validation_notes,
        wo.predictive_outcome,
        wo.predictive_outcome_notes
    FROM work_orders wo
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE wo.due_date < NOW()
      AND wo.status NOT IN ('COMPLETED', 'VALIDATED', 'CLOSED', 'CANCELLED')
      AND COALESCE(wo.is_archived, false) = false
    ORDER BY wo.due_date ASC
    LIMIT 20;
    """
    return run_query(sql)


def work_orders_by_status():
    sql = """
    SELECT
        status,
        COUNT(*) AS count
    FROM work_orders
    WHERE COALESCE(is_archived, false) = false
    GROUP BY status
    ORDER BY count DESC;
    """
    return run_query(sql)


def claims_by_priority():
    sql = """
    SELECT
        priority,
        COUNT(*) AS count
    FROM claims
    GROUP BY priority
    ORDER BY count DESC;
    """
    return run_query(sql)


# =========================
# Additional production SQL queries
# =========================

def blocked_tasks(limit: int = 20):
    limit = max(1, min(int(limit), 50))

    sql = """
    SELECT
        t.task_id,
        ('tasks_' || t.task_id) AS source_id,
        t.wo_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        t.title,
        t.description,
        t.status,
        t.priority,
        t.blocked_reason,
        t.failure_reason,
        t.notes,
        t.due_date,
        t.started_at,
        t.completed_at
    FROM tasks t
    JOIN work_orders wo ON wo.wo_id = t.wo_id
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE t.status = 'BLOCKED'
       OR t.blocked_reason IS NOT NULL
    ORDER BY
        CASE
            WHEN t.priority = 'CRITICAL' THEN 1
            WHEN t.priority = 'HIGH' THEN 2
            WHEN t.priority = 'MEDIUM' THEN 3
            ELSE 4
        END,
        t.due_date ASC NULLS LAST
    LIMIT %s;
    """
    return run_query(sql, [limit])


def cancelled_work_orders(limit: int = 20):
    limit = max(1, min(int(limit), 50))

    sql = """
    SELECT
        wo.wo_id,
        ('work_orders_' || wo.wo_id) AS source_id,
        wo.claim_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        wo.title,
        wo.description,
        wo.status,
        wo.priority,
        wo.wo_type,
        wo.cancellation_notes,
        wo.created_at,
        wo.updated_at,
        wo.due_date
    FROM work_orders wo
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE wo.status = 'CANCELLED'
      AND COALESCE(wo.is_archived, false) = false
    ORDER BY wo.updated_at DESC NULLS LAST
    LIMIT %s;
    """
    return run_query(sql, [limit])


def high_priority_claims(limit: int = 20):
    limit = max(1, min(int(limit), 50))

    sql = """
    SELECT
        c.claim_id,
        ('claims_' || c.claim_id) AS source_id,
        c.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.criticality,
        c.title,
        c.description,
        c.status,
        c.priority,
        c.reported_severity,
        c.validated_severity,
        c.qualification_notes,
        c.created_at,
        c.updated_at
    FROM claims c
    JOIN equipment e ON e.equipment_id = c.equipment_id
    WHERE c.priority IN ('CRITICAL', 'HIGH')
    ORDER BY
        CASE
            WHEN c.priority = 'CRITICAL' THEN 1
            WHEN c.priority = 'HIGH' THEN 2
            ELSE 3
        END,
        c.created_at DESC
    LIMIT %s;
    """
    return run_query(sql, [limit])


def equipment_summary_by_id(equipment_id: int):
    sql = """
    SELECT
        e.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        e.status,
        e.location,
        e.manufacturer,
        e.supplier_name,
        e.purchase_date,
        e.commissioning_date,
        e.warranty_end_date
    FROM equipment e
    WHERE e.equipment_id = %s;
    """
    return run_query(sql, [equipment_id])


# =========================
# HYBRID helper:
# top equipment by claims explanation
# =========================

def get_related_records_for_equipment(equipment_ids):
    """
    SQL finds top equipment, then this fetches a compact number of related
    claims, work orders, and tasks for those equipment IDs.

    Used for:
    - Why do the top equipment have the most claims?
    - Causes behind top equipment by claim count.
    """

    if not equipment_ids:
        return {
            "claims": [],
            "work_orders": [],
            "tasks": [],
        }

    sql_claims = """
    SELECT
        ('claims_' || c.claim_id) AS source_id,
        c.claim_id,
        c.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        c.title,
        c.description,
        c.status,
        c.priority,
        c.qualification_notes,
        c.reported_severity,
        c.validated_severity,
        c.created_at,
        c.updated_at,
        c.resolved_at,
        c.closed_at
    FROM claims c
    JOIN equipment e ON e.equipment_id = c.equipment_id
    WHERE c.equipment_id = ANY(%s)
    ORDER BY
        CASE
            WHEN c.priority = 'CRITICAL' THEN 1
            WHEN c.priority = 'HIGH' THEN 2
            WHEN c.priority = 'MEDIUM' THEN 3
            ELSE 4
        END,
        c.created_at DESC
    LIMIT 9;
    """

    sql_work_orders = """
    SELECT
        ('work_orders_' || wo.wo_id) AS source_id,
        wo.wo_id,
        wo.claim_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        wo.title,
        wo.description,
        wo.status,
        wo.priority,
        wo.wo_type,
        wo.created_at,
        wo.updated_at,
        wo.due_date,
        wo.planned_start,
        wo.planned_end,
        wo.completed_at,
        wo.cancellation_notes,
        wo.completion_notes,
        wo.validation_notes,
        wo.predictive_outcome,
        wo.predictive_outcome_notes
    FROM work_orders wo
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE wo.equipment_id = ANY(%s)
      AND COALESCE(wo.is_archived, false) = false
    ORDER BY
        CASE
            WHEN wo.priority = 'CRITICAL' THEN 1
            WHEN wo.priority = 'HIGH' THEN 2
            WHEN wo.priority = 'MEDIUM' THEN 3
            ELSE 4
        END,
        wo.created_at DESC
    LIMIT 9;
    """

    sql_tasks = """
    SELECT
        ('tasks_' || t.task_id) AS source_id,
        t.task_id,
        t.wo_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        t.title,
        t.description,
        t.status,
        t.priority,
        t.blocked_reason,
        t.failure_reason,
        t.notes,
        t.due_date,
        t.started_at,
        t.completed_at
    FROM tasks t
    JOIN work_orders wo ON wo.wo_id = t.wo_id
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE wo.equipment_id = ANY(%s)
    ORDER BY
        CASE
            WHEN t.status = 'BLOCKED' THEN 1
            WHEN t.priority = 'CRITICAL' THEN 2
            WHEN t.priority = 'HIGH' THEN 3
            ELSE 4
        END,
        t.due_date DESC NULLS LAST
    LIMIT 9;
    """

    return {
        "claims": run_query(sql_claims, [equipment_ids]),
        "work_orders": run_query(sql_work_orders, [equipment_ids]),
        "tasks": run_query(sql_tasks, [equipment_ids]),
    }


# =========================
# HYBRID helper:
# overdue work order delay explanation
# =========================

def get_related_records_for_work_orders(wo_ids):
    """
    SQL finds overdue work orders, then this fetches linked work orders,
    claims, and tasks.

    Used for:
    - Why are overdue work orders delayed?
    - Why are work orders in delay?
    """

    if not wo_ids:
        return {
            "claims": [],
            "work_orders": [],
            "tasks": [],
        }

    sql_work_orders = """
    SELECT
        ('work_orders_' || wo.wo_id) AS source_id,
        wo.wo_id,
        wo.claim_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        wo.title,
        wo.description,
        wo.status,
        wo.priority,
        wo.wo_type,
        wo.created_at,
        wo.updated_at,
        wo.due_date,
        wo.planned_start,
        wo.planned_end,
        wo.completed_at,
        wo.cancellation_notes,
        wo.completion_notes,
        wo.validation_notes,
        wo.predictive_outcome,
        wo.predictive_outcome_notes
    FROM work_orders wo
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE wo.wo_id = ANY(%s)
    ORDER BY wo.due_date ASC NULLS LAST
    LIMIT 20;
    """

    sql_claims = """
    SELECT
        ('claims_' || c.claim_id) AS source_id,
        c.claim_id,
        c.equipment_id,
        c.linked_wo_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        c.title,
        c.description,
        c.status,
        c.priority,
        c.qualification_notes,
        c.reported_severity,
        c.validated_severity,
        c.created_at,
        c.updated_at
    FROM claims c
    JOIN equipment e ON e.equipment_id = c.equipment_id
    WHERE c.linked_wo_id = ANY(%s)
       OR c.claim_id IN (
            SELECT claim_id
            FROM work_orders
            WHERE wo_id = ANY(%s)
              AND claim_id IS NOT NULL
       )
    ORDER BY c.created_at DESC
    LIMIT 20;
    """

    sql_tasks = """
    SELECT
        ('tasks_' || t.task_id) AS source_id,
        t.task_id,
        t.wo_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        e.model,
        e.criticality,
        t.title,
        t.description,
        t.status,
        t.priority,
        t.blocked_reason,
        t.failure_reason,
        t.notes,
        t.due_date,
        t.started_at,
        t.completed_at
    FROM tasks t
    JOIN work_orders wo ON wo.wo_id = t.wo_id
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE t.wo_id = ANY(%s)
    ORDER BY
        CASE
            WHEN t.status = 'BLOCKED' THEN 1
            WHEN t.priority = 'CRITICAL' THEN 2
            WHEN t.priority = 'HIGH' THEN 3
            ELSE 4
        END,
        t.due_date DESC NULLS LAST
    LIMIT 30;
    """

    return {
        "claims": run_query(sql_claims, [wo_ids, wo_ids]),
        "work_orders": run_query(sql_work_orders, [wo_ids]),
        "tasks": run_query(sql_tasks, [wo_ids]),
    }


# =========================
# HYBRID helper:
# spare part impact explanation
# =========================

def get_related_records_for_low_stock_parts(part_ids):
    """
    SQL finds low-stock parts, then this fetches part usage and related
    work orders/tasks.

    Used later for:
    - Why are low-stock spare parts affecting maintenance?
    """

    if not part_ids:
        return {
            "spare_parts": [],
            "part_usage": [],
            "work_orders": [],
            "tasks": [],
        }

    sql_spare_parts = """
    SELECT
        ('spare_parts_' || sp.part_id) AS source_id,
        sp.part_id,
        sp.sku,
        sp.name,
        sp.category,
        sp.quantity_in_stock,
        sp.min_stock_level,
        sp.unit_cost,
        sp.location,
        sp.supplier
    FROM spare_parts sp
    WHERE sp.part_id = ANY(%s)
    LIMIT 20;
    """

    sql_part_usage = """
    SELECT
        pu.usage_id,
        pu.part_id,
        pu.wo_id,
        pu.task_id,
        pu.quantity_used,
        pu.unit_cost,
        pu.total_cost,
        sp.sku,
        sp.name AS part_name,
        sp.quantity_in_stock,
        sp.min_stock_level
    FROM part_usage pu
    JOIN spare_parts sp ON sp.part_id = pu.part_id
    WHERE pu.part_id = ANY(%s)
    ORDER BY pu.usage_id DESC
    LIMIT 30;
    """

    sql_work_orders = """
    SELECT DISTINCT
        ('work_orders_' || wo.wo_id) AS source_id,
        wo.wo_id,
        wo.claim_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        e.classification,
        e.category,
        wo.title,
        wo.description,
        wo.status,
        wo.priority,
        wo.due_date,
        wo.predictive_outcome,
        wo.predictive_outcome_notes
    FROM part_usage pu
    JOIN work_orders wo ON wo.wo_id = pu.wo_id
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE pu.part_id = ANY(%s)
    ORDER BY wo.due_date ASC NULLS LAST
    LIMIT 20;
    """

    sql_tasks = """
    SELECT DISTINCT
        ('tasks_' || t.task_id) AS source_id,
        t.task_id,
        t.wo_id,
        wo.equipment_id,
        e.asset_code,
        e.name AS equipment_name,
        t.title,
        t.description,
        t.status,
        t.priority,
        t.blocked_reason,
        t.failure_reason,
        t.notes,
        t.due_date
    FROM part_usage pu
    JOIN tasks t ON t.task_id = pu.task_id
    JOIN work_orders wo ON wo.wo_id = t.wo_id
    JOIN equipment e ON e.equipment_id = wo.equipment_id
    WHERE pu.part_id = ANY(%s)
    ORDER BY t.due_date ASC NULLS LAST
    LIMIT 20;
    """

    return {
        "spare_parts": run_query(sql_spare_parts, [part_ids]),
        "part_usage": run_query(sql_part_usage, [part_ids]),
        "work_orders": run_query(sql_work_orders, [part_ids]),
        "tasks": run_query(sql_tasks, [part_ids]),
    }


# =========================
# Health check helpers
# =========================

def test_sql_tools():
    """
    Simple local diagnostic.
    Run:
        python -c "from sql_tools import test_sql_tools; test_sql_tools()"
    """

    print("Testing SQL tools...")

    checks = [
        ("top_equipment_by_claims", lambda: top_equipment_by_claims(3)),
        ("count_open_work_orders", count_open_work_orders),
        ("count_open_claims", count_open_claims),
        ("spare_parts_below_min_stock", spare_parts_below_min_stock),
        ("overdue_work_orders", overdue_work_orders),
        ("work_orders_by_status", work_orders_by_status),
        ("claims_by_priority", claims_by_priority),
        ("blocked_tasks", blocked_tasks),
        ("cancelled_work_orders", cancelled_work_orders),
        ("high_priority_claims", high_priority_claims),
    ]

    for name, fn in checks:
        try:
            rows = fn()
            print(f"{name}: OK ({len(rows)} rows)")
        except Exception as e:
            print(f"{name}: ERROR - {e}")